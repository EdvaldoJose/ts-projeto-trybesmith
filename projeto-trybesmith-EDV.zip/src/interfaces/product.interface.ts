interface Product {
  id?: number;
  name: string;
  amount: number;
}

export default Product;