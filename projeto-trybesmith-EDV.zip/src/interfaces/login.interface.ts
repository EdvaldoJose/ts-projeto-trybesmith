interface Login {
  username: string;
  password: string;
}

export default Login;